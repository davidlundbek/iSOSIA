function template()

close all;

%mesh dimensions
L = 29.5e3; H = 14.1e3; 
nx = 295; ny = 141; 

%load default SPM structure
SPM = setup(L,H,nx,ny);
SPM.mesh.doice = 1;
SPM.mesh.dosliding = 1;  %sliding flag
SPM.mesh.doglacialerosion = 0;
SPM.mesh.doglacialhydrology = 1;
SPM.mesh.dosediment = 1;
SPM.mesh.doavalance = 1;
SPM.mesh.coldbased = 0;  %coldbased ice
SPM.mesh.doparticles = 1;  
SPM.mesh.doisostasy = 0; %isostasy flag
SPM.mesh.nmoni = 10; %how often to output time series data
SPM.mesh.maxtime = 10000;  %length of simulation (y)
SPM.mesh.filetime = 100;  %time between outputs
SPM.mesh.maxdt = 1.0;    %maximum time step
SPM.mesh.ct = 0.1;       %time step scaling factor
SPM.mesh.slidingmode = 3; %0:weertman, 1:budd , 2:Schoof, 3: cavity-based
SPM.mesh.dohillslope = 0; %hillslope transport
SPM.mesh.dohillslopeerosion = 1; %bedrock erosion on hillslopes
SPM.mesh.dodeposit = 0;
SPM.mesh.doweathering = 0;
SPM.mesh.douniformerosion = 1;
SPM.mesh.dopulse = 1;

%SPM.mesh.maxb = 10;     %maximum bed gradient
%SPM.mesh.maxs = 10;     %maximum ice surface gradient


%****** ice properties *************
SPM.iprop.ifac = 0.01;       %Relaxation constant (velocity)
SPM.iprop.sfac = 0.1;        %Relaxation constant (stress)
SPM.iprop.vbfac = 0.001;      %Relaxation constant (sliding)
SPM.iprop.maxitt_v = 400;    %Max iteration (velocity)
SPM.iprop.maxitt_s = 100;    %Max iteration (stress)
SPM.iprop.Cs = 2.39*1e-2;       %Sliding parameter
SPM.iprop.gamma0 = 1.0e-2;  %Viscosity regelation

%glacial erosion
SPM.iprop.Kq = 0;          %quarrying constant
SPM.iprop.Ka = 0;         %abrasion constant
SPM.iprop.ap = 3.0;          %abrasion sliding power

                           
%**** mass balance parameters *********
SPM.mprop.mtype = 2; %PDD model
SPM.mprop.avaslope = 0.4; %max stable slope for avalances
SPM.mprop.avacurv = -0.001;  %min stable curvature for avalances (wind)
SPM.mprop.lrate = 0.006;   %lapse rate
SPM.mprop.mPDD = 1.0e-3; %2.0
SPM.mprop.dTa = 5;
SPM.mprop.maxacc = 2.25;  %maximum accumulation rate         
 
%**** hillslope processes *********
SPM.hprop.Ks = 5;       %hillslope diffusivity
SPM.hprop.sc = 1.4;        %critical slope
SPM.hprop.Ke = 0;        %Hillslope erosion coefficient

%****** hwprop data ******
SPM.hwprop.a2w = 1;     %fraction of ablation to glacial water 
SPM.hwprop.tscale = 1;     %time scaling < 1 slows system and
                           %increase timesteps
SPM.hwprop.kh = 0.3695;    %run code htest.m to find these
SPM.hwprop.h0 = 0.1;  
SPM.hwprop.ds = 0.25;
SPM.hwprop.ss0 = 0.3;
SPM.hwprop.kmin = 4.0e-03;    %min transmicity for cavities 
SPM.hwprop.alpha = 0.7;    %cavity area scaling 
SPM.hwprop.Ls = 4;         %Cavity spacing
SPM.hwprop.Lc = 200;       %Channel spacing
SPM.hwprop.minqw = 1e-4;   %max water flux
SPM.hwprop.S0 = 0.1;       %min cavity length
SPM.hwprop.A0 = 0.1;       %min channel cross section
SPM.hwprop.dtw = 0.1;      %time step scaling

%***** Sediment particles ************** 
SPM.parprop.npmax = 2e6; %max number of particles
SPM.parprop.L0 = 2000; %particle abrasion power decay length
SPM.parprop.minice = 5; %minimum ice thickness for ice transport
SPM.parprop.minsedi = 0.01; %minimum sediment thickness for particle formation
SPM.parprop.maxsedi = 0.01; %max sediment per particle
SPM.parprop.maxpm = 100; %max particle number in margin cell
SPM.parprop.maxp = 1000; %max particle number in ordinary cell
SPM.parprop.minpm = 0; %minimum particle number at margin 
SPM.parprop.minsedim = 0; %mimum sediment pickup at margin
                          %The two latter parameters are used to
                          %form sediment along margins without
                          %production of sediment in the landscape
SPM.parprop.vub = 1; %velocity constant for basal particles speed

%Sea level temperature thorugh time
time = linspace(0,SPM.mesh.maxtime,200); %time vector in years
T0 =  9 - 0*cos(2*pi*time/20e3);  %sea level temp 
SPM.mprop.Temp = [time(:)';T0(:)'];   %t;T data


%prepare bed topography
%grid details
x = linspace(0,SPM.mesh.L,SPM.mesh.nx);
y = linspace(0,SPM.mesh.H,SPM.mesh.ny);
[X,Y] = meshgrid(x,y);

%loading and interpolating fluvial model
load Tiedemann.mat; 
% efac = 0.02;
% F = TriScatteredInterp((1+efac)*coord(:,1),(1+efac)*coord(:,2)-0.5*efac*H,h);
% bed = F(X,Y);
% bed = 3500/max(bed(:))*bed;
x=linspace(0,L,nx);
y=linspace(0,H,ny);
nu=0.8; %roughness
Lx=500; %wave length
seed=1; %same random numbers
karmanM=karman2d(x,y,nu,Lx,seed);
karmanM=2*(karmanM-min(karmanM(:)))/(max(karmanM(:))-min(karmanM(:)))-1;%normilized Von Karman
phi = 0.75 + 0*karmanM;

%save input data on grid 
load('include.mat'); %load polygon coordinates
SPM.data.bed = bed;
SPM.data.Ka = SPM.iprop.Ka*ones(SPM.mesh.ny,SPM.mesh.nx);
SPM.data.Kq = SPM.iprop.Kq.*ones(SPM.mesh.ny,SPM.mesh.nx);
SPM.data.include = polyg_Tied; %Tiedemann glacier catchment
SPM.data.phi = phi;

%mass balance function (positive degree day)
SPM = massbalance(SPM,1);

% %plot input topography
figure
surf(X,Y,bed); axis equal, 


%write input files
write(SPM);
