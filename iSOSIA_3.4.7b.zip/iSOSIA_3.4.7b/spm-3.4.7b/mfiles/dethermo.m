function dethermo(varargin)
% This script set thermochronological ages and compute detrital age
% distributions for iSOSIA models presented in Bernard et al. (2020). To 
% run the script you need to be in an iSOSIA model folder. It started with 
% a list of parameters to set according to the iSOSIA models where to 
% compute the detrital age distributions. The values of the parameters to 
% use are the followings:
%
%  - Tied_UniformPart: This model considers a uniform pulse production of 
%    particles across the catchment. It refers to the results presented in
%    figures 5 and 6. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 1   
%
%  - Tied_Uniform: This model considers a uniform constant production of
%    particles across the catchment. It refers to results presented in figure
%    7. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_Uniform (hillslope sources): This model considers a uniform 
%    constant production of particles across the catchment. However, only
%    particles from hillslopes are sampled in the frontal moraine. It 
%    refers to results presented in figure 8. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 1    glacial = 0   Pulse = 0
%
%  - Tied_Uniform (glacial sources): This model considers a uniform 
%    constant production of particles across the catchment. However, only
%    particles from hillslopes are sampled in the frontal moraine. It
%    refers to results presented in figure 8. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 1   Pulse = 0
%
%  - Tied_NonUniform: This model considers a non-uniform constant production of
%    particles across the catchment. It refers to results presented in figure
%    9. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_Uniform (Local sampling): This model considers a uniform constant 
%    production of particles across the catchment. It refers to results 
%    presented in figure 11. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 2
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_M16: This model considers a uniform pulse production of particles
%    across the catchment. However, the glacier length is ~1000 m shorter than
%    the reference model. It refers to results presented in figures S11 and S12.
%    Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 3
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_M16_CP: This model considers a uniform continuous production of particles
%    across the catchment. However, the glacier length is ~1000 m shorter than
%    the reference model. It refers to results presented in figures S11 and S12.
%    Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 3
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_M17: This model considers a uniform pulse production of particles
%    across the catchment. However, the glacier length is ~1000 m taller than
%    the reference model. It refers to results presented in figures S11 and S12.
%    Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 4
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_M17_CP: This model considers a uniform continuous production of particles
%    across the catchment. However, the glacier length is ~1000 m taller than
%    the reference model. It refers to results presented in figures S11 and S12.
%    Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 4
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_Hill1: This model considers a uniform pulse production of particles
%    across the catchment. However, the diffusivity on hillslope is lower than
%    the reference model (Kh = 0.5 m�/yr). It refers to results presented in
%    figures S11 and S12. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_Hill1_CP: This model considers a uniform continuous production of particles
%    across the catchment. However, the diffusivity on hillslope is lower than
%    the reference model (Kh = 0.5 m�/yr). It refers to results presented in
%    figures S11 and S12. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_Hill3: This model considers a uniform pulse production of particles
%    across the catchment. However, the diffusivity on hillslope is greater than
%    the reference model (Kh = 20 m�/yr). It refers to results presented in
%    figures S11 and S12. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 0
%
%  - Tied_Hill3_CP: This model considers a uniform continuous production of particles
%    across the catchment. However, the diffusivity on hillslope is greater than
%    the reference model (Kh = 20 m�/yr). It refers to results presented in
%    figures S11 and S12. Parameters values are
%    AgeElev = 1 or 2 (AFT or AHe)        Ssite = 1
%    Hillslope = 0    glacial = 0   Pulse = 0
close all;
%------------------------ Parameters to set ---------------------------------
Age_Elevation =2;          %Thermochronological ages: 1= AFT, 2=AHe
Sampling_site = 1;         %Coordinates of the sampling site
hillslope_bedrock = 0;     %Sample hillslope-origin particles only
glacial_bedrock = 0;       %Sample glacier-oriing particles only
Pulse = 0;                 %For models with a pulse of particles production 
show_particles = 0;        %To show spatial distribution of particles at the end 

%Input variables
if nargin > 0,   
  lArgin = varargin;
  while length(lArgin) >= 1,
    type = lArgin{1};
    lArgin = lArgin(2:end);
    switch type,
     case{'AgeElev'}
      Age_Elevation = lArgin{1};
      lArgin = lArgin(2:end);
     case{'Ssite'}
      Sampling_site = lArgin{1};
      lArgin = lArgin(2:end);
     case{'hillslope'}
      hillslope_bedrock = 1;
     case{'glacial'}
      glacial_bedrock = 1;
     case{'pulse'}
      Pulse = 1;
     case{'showpart'}
      show_particles = 1;
    end;
  end;
end;

%---------------------- Other parameters ----------------------------------
alpha_pdf = 0.6;        %alpha value in Brandon (1996)
nb_grains = 105;        %number of particles to sample
ntry = 10000;           %Repeat the process of building SPDF 10,000 times
Temporary = 'Temporary.mat'; save(Temporary); %Matrix to store parameters temporarly

%---------------------------- Load parameters ----------------------------
%if AFT ages selected
if Age_Elevation==1
    NameExp = 'AFT';            %Name for figures output
    y_lim = 0.008;              %Ylim for SPDF plot (probability)
    dt_age = 0.1; max_age= 100; 
    x_lim = 100;                %Xlim for SPDF plot (Ages)
    Age_range = linspace(0,max_age,max_age/dt_age); %Range of ages  
    std_gauss = 0;              %The uncertainty on the AFT ages is computed later
else %if AHe ages selected
    NameExp = 'AHe';            %Name for figures output
    y_lim = 0.04;               %Ylim for SPDF plot (probability)
    dt_age = 0.1; max_age = 20;
    Age_range = linspace(0,max_age,max_age/dt_age); %Range of ages
    x_lim = 20;                 %Xlim for SPDF plot (Ages)
    std_gauss = 0.1;            %10% relative uncertainty on the AHe ages
end

if Pulse == 1
    fnr_vector = [15,20,30,95]; %iSOSIA output file number to extract data, fnr = 30 = 2000 years of sediment transports
else
    fnr_vector = 30;
end
fnr = fnr_vector(1);

if Sampling_site == 1
    xg = [22.550,24.650,24.650,22.550]; yg = [5.550,5.550,4.350,4.350]; %Frontal moraine area for the reference model
elseif Sampling_site == 2 %Frontal moraine area for model M17
    xFM1 = [22.550,23.550,23.550,22.550]; yFM1 = [4.550,4.550,4.350,4.350];
    xFM2 = [22.550,23.550,23.550,22.550]; yFM2 = [4.850,4.850,4.650,4.650];
    xFM3 = [22.550,23.550,23.550,22.550]; yFM3 = [5.150,5.150,4.950,4.950];
    xFM4 = [22.550,23.550,23.550,22.550]; yFM4 = [5.450,5.450,5.250,5.250];
    xg=[xFM1;xFM2;xFM3;xFM4]; yg = [yFM1;yFM2;yFM3;yFM4];
    Ssize = size(xg);
elseif Sampling_site == 3 %Frontal moraine area for model M16
    xg = [21.150,24.650,24.650,21.150]; yg = [5.550,5.550,4.250,4.250]; 
elseif Sampling_site == 4 %Frontal moraine area for model M17
    xg = [23.550,24.650,24.650,23.550]; yg = [5.550,5.550,4.350,4.350];
end

%save parameters
save(Temporary,'xg','yg','alpha_pdf','Age_range','nb_grains',...
    'std_gauss','dt_age','y_lim','Age_Elevation','ntry',...
    'fnr','nb_grains','-append');

%Load masks parameters
load cmap_jet.mat;   %load colorbar
load('include.mat'); %mask for the Tiedemann glacier catchment
SPM = SPMload;       %Load input parameters of the iSOSIA model 
dx = SPM.mesh.dx;    %grid cell dimension
dy = SPM.mesh.dy;    %grid cell dimension
nx = SPM.mesh.nx; ny = SPM.mesh.ny; %Model resolution
%Build the model grid
[Xc, Yc] = meshgrid([1:nx]*dx-dx/2,[1:ny]*dy-dy/2); 
Xkm = Xc ./1000; Ykm = Yc./1000;

%------------------------ getting Ice margins --------------------------------------
loaddata; %load output data

%search for glacier margins
minice = 1e-3;
margin_ice = zeros(size(icemargin));
for i=1:ny
    for j=1:nx
        if ice(i,j) < minice
            margin_ice(i,j) = 0; %Ice-free cell
        else
            if ice(i,j-1) < minice || ice(i+1,j) < minice || ice(i,j+1) < minice || ice(i-1,j) < minice
                margin_ice(i,j) = 1; %Glacier margin
            else 
                margin_ice(i,j) = -1; %Glacier
            end
        end
    end
end

%------------------------- Set Thermochronological ages ---------------
%Age_Elevation profile
ThermoAge = [17,16.7,19.8,15.5,15.5,11.6,14.3,22.2,10.8,42.7,87.4]; %Bedrock AFT ages from Enkelmann and Ehlers (2015).
AgeElev = [0,387,681,1370,1612,1896,1930,2207,2225,2651,4000];   %Corresponding elevations (m)
Myr = 1e-6;                   %To convert in Myr
dt = SPM.mesh.filetime * Myr; %iSOSIA output file time step in Myr

%linear regressions on discrete ages
c1 = polyfit(AgeElev(1,2:7),ThermoAge(1,2:7),1); %get regression of the age-elevation profile below 2000m
c1b = ThermoAge(1,2:7); c1c = c1(2) + AgeElev(1,1:8) * c1(1); 
c2 = polyfit(AgeElev(5:10),ThermoAge(5:10),1); %get regression of the age-elevation profile above 2000m
c2b = ThermoAge(5:end); c2c = c2(2) + AgeElev(5:end) * c2(1);
[Age_inter,Elev_inter] = polyxpoly(c1c,AgeElev(1:8),c2c,AgeElev(5:end)); %search for intersection point
c = [c1c(1:5),c2c(2:end)]; c(6) = Age_inter;
AgeElev(6) = Elev_inter;
ThermoAge = c;

if Age_Elevation == 2 %If AHe ages
    AgeElev = linspace(AgeElev(1),AgeElev(end),11);
    ThermoAge = (AgeElev + 266) ./ 307; %equation from Ehlers et al. (2015)
end

%Get bedrock ages across the model grid
resh_bed = reshape(bed,[1,nx*ny]);                     %Store the bed grid in an array
Thermo_ages = interp1(AgeElev, ThermoAge, resh_bed);   %Interpolate ages according to the bed elevation values
save(Temporary,'Thermo_ages','-append');

%Plot Bedrock age distribution
Ages_bedrock = reshape(Thermo_ages(1,:),[ny,nx]);
Ages_bedrock = Ages_bedrock .* polyg_Tied;        %Keep ages within the Tiedemann glacier catchment

%Crop bedrock ages according to the upstream area of sampling sites
if hillslope_bedrock == 1  %to consider bedrock age distribution of hillslope sediment sources only, 22550 is the location of the frontal moraine
    indx = find(Xc <= 22550 & polyg_Tied == 1 & ice <= 5);
    bedrock_ages_crop = Ages_bedrock(indx);
elseif glacial_bedrock == 1 %to consider bedrock age distribution of glaciers sediment sources only
    indx = find(Xc <= 22550 & polyg_Tied == 1 & ice > 5);
    bedrock_ages_crop = Ages_bedrock(indx);
else  %if consider all sources across the catchment upstream the sampling site
    indx = find(Xc <= 22550 & polyg_Tied == 1);
    bedrock_ages_crop = Ages_bedrock(indx);    
end

save(Temporary,'bedrock_ages_crop','bed','Ages_bedrock','dx','dy',...
    '-append');

%--------------------- Hyposmetry -----------------------------------------
%Frequency vs Altitude
figure
loaddata;
bed_crop = bed(polyg_Tied==1 & Xc <= 22150); 
bed_crop_hill = bed(polyg_Tied==1 & Xc <= 22150 & ice<=5); %Hillslope sediment sources
bed_crop_glac = bed(polyg_Tied==1 & Xc <= 22150 & ice>5); %Glaciers sediment sources
bed_min = min(bed_crop(:)); bed_max = max(bed_crop(:));
Elevation_range = linspace(bed_min-1,bed_max+1,max_age/dt_age);
init_elev_bin = histcounts(bed_crop,Elevation_range);
init_elev_bin = init_elev_bin ./ length(bed) .*100;
elev_bin = histcounts(bed_crop,Elevation_range,'Normalization','pdf'); %get catchment hypsometry frequency
elev_binhill = histcounts(bed_crop_hill,Elevation_range,'Normalization','pdf'); %get hillslope sources hypsometry frequency
elev_binglac = histcounts(bed_crop_glac,Elevation_range,'Normalization','pdf'); %get glaciers sources hypsometry frequency
elev_bin = [elev_bin, 0]; init_elev_bin = [init_elev_bin,0]; %Handle range bin
elev_binhill = [elev_binhill, 0];elev_binglac = [elev_binglac, 0];

%Plot hypsometry frequencies
hold on; grid off; box off; 
plot(Elevation_range,elev_binhill,'r-');
plot(Elevation_range,elev_binglac,'b-');
plot(Elevation_range,elev_bin,'k-');
ylabel('Frequency'); xlabel('Elevation (m)');
legend('Hillslope','Glaciers','Catchment')
xlim([0 4000])
set(gca,'FontSize',8,'FontName','Arial');
hold off;

figure %Plot the ice margins and location of the sampling site
[cdata_M,~,~] = get_color(bed,colormap(cmap_jet),[0,5],1,1,bed,0);
s1=surf(Xkm, Ykm, bed./1000,'Cdata',cdata_M); hold on; shading interp;
loaddata;
[cdata_N,~,~] = get_color(margin_ice,colormap(cmap_jet),[0,5],0,1,bed,0);
bedNan = bed+10; bedNan(polyg_Tied==0) = NaN;
s1=surf(Xkm, Ykm, bedNan./1000,'Cdata',cdata_N); hold on; shading interp;
set(gca,'dataaspectratio',[1,1,1/1]);
xlabel('Distance (km)'); ylabel('Distance (km)');
view([90,90])


%--------------------- Main loop - Compute detrital ages and SPDFs ------------------------------------------
SPDFs_for_transient = zeros(length(fnr_vector),length(Age_range)); %Iniate matrix to store detrital SPDFs for model considering pulse of particles

%Compute bedrock SPDF
Bedrock_SPDFs = get_SPDF(bedrock_ages_crop');

%Go through iSOSIA output file(s)
for k=1:length(fnr_vector)
    
    fnr = fnr_vector(k); %Get the output file number
    
    %load relevant information
    SPM = SPMload;
    loaddata;

    %Get Thermochronological ages
    loadparticles;%load birthday (time formation of particle),age (particle lifetime),xp,yp,zp,erate,bx,by,npa

    %Get Thermochronological ages for particles according to their source location 
    Tages_resh = reshape(Thermo_ages, [ny,nx]);
    ik = floor(bx./dx)+1; jk = floor(by./dy)+1; indx_age=sub2ind(size(Tages_resh),jk,ik);
    Ages_particles = Tages_resh(indx_age); %Assign ages to particles
    save(Temporary,'Ages_particles','Xc','Yc','nx','ny','fnr','-append')

    %-------------------- Sample particles -----------------------------
    %Find cells in the sampling site
    if Sampling_site == 2  %if sample the regions within the frontal moraine    
        Detrital_SPDFs_local = zeros(Ssize(1),numel(Age_range)); %Initiate matrix to store detrital SPDFs of the four regions
        
        for si=1:Ssize(2) %Go within regions
            %find the cells to sample
            NB_cell = find(Xkm >= xg(si,1)-dx/2./1000 & Xkm <= xg(si,2)+dx/2./1000 & Ykm <= yg(si,1)+dy/2./1000 & Ykm >= yg(si,3)-dy/2./1000);
            X = Xc(NB_cell); %Coordinates of cells of the sampling site
            Y = Yc(NB_cell);
            %Plot the cells of the sampling sites
            Xp = Xkm(NB_cell); %Coordinates of cells
            Yp = Ykm(NB_cell);
            zl = [5,5,5,5,5];
            Col = [rand(1),rand(1),rand(1)]; %Color for regions
            for xindx=1:length(NB_cell)
                xg2 = (Xp(xindx)-(dx/2)./1000); yg2 = (Yp(xindx)-(dy/2)/1000);
                xvec = [Xp(xindx)+(dx/2)/1000,Xp(xindx)+(dx/2)/1000,xg2,xg2,Xp(xindx)+(dx/2)/1000]; yvec=[Yp(xindx)+(dy/2)/1000,yg2,yg2,Yp(xindx)+(dy/2)/1000,Yp(xindx)+(dy/2)/1000];
                pline1 = line(xvec,yvec,zl,'Color',Col,'Parent',gca);
            end
            hold off;
            
            %find particles within the cells
            ip = 1:npa;
            pwanted = 0;
            agesp = zeros(1,npa);
            indxpart = zeros(size(agesp));
            count = 0;
            
            for icell = 1:length(NB_cell)
                pfound = find(abs(xp(ip)-(X(icell))) <= (dx./2) & abs(yp(ip)-(Y(icell))) <= (dy./2))';
                count = count+length(pfound);
                nbp = length(pfound); %number of particle in the sampled cell
                agesp(count-length(pfound)+1:count) = Ages_particles(pfound); %Particles thermochronological age in the cell
                indxpart(count-length(pfound)+1:count) = pfound';
            end
            agesp(count+1:end) = [];

            %----- compute SPDFs -----%
            Detrital_SPDFs = get_SPDF(agesp);
            Detrital_SPDFs_local(si,:) = mean(Detrital_SPDFs);
        end
    else
        %find the cells 
        NB_cell = find(Xkm >= xg(1)-dx/2./1000 & Xkm <= xg(2)+dx/2./1000 & Ykm <= yg(1)+dy/2./1000 & Ykm >= yg(3)-dy/2./1000);
        %Plot bed topography
        X = Xkm(NB_cell); %Coordinates of cells
        Y = Ykm(NB_cell);
        zl = [5,5,5,5,5];
        for xindx=1:length(NB_cell)
            xg2 = (X(xindx)-(dx/2)./1000); yg2 = (Y(xindx)-(dy/2)/1000);
            xvec = [X(xindx)+(dx/2)/1000,X(xindx)+(dx/2)/1000,xg2,xg2,X(xindx)+(dx/2)/1000]; yvec=[Y(xindx)+(dy/2)/1000,yg2,yg2,Y(xindx)+(dy/2)/1000,Y(xindx)+(dy/2)/1000];
            pline1 = line(xvec,yvec,zl,'Color','r','Parent',gca);
        end
        hold off;
            
        X = Xc(NB_cell); %Coordinates of cells of the sampling site
        Y = Yc(NB_cell);
        %find particles inside the cell
        ip = 1:npa;
        agesp = zeros(1,npa); %Initiate vector to store particles within the sampling site
        count = 0;
        for icell = 1:length(NB_cell)
            if hillslope_bedrock == 1 %To sample hillslope-origin particles only
                pfound = find(abs(xp(ip)-(X(icell))) <= (dx./2) & abs(yp(ip)-(Y(icell))) <= (dy./2) & typep==-1)';
            elseif glacial_bedrock == 1 %To sample glacial-origin particles only
                pfound = find(abs(xp(ip)-(X(icell))) <= (dx./2) & abs(yp(ip)-(Y(icell))) <= (dy./2) & typep==1)';
            else %To sample particles 
                pfound = find(abs(xp(ip)-(X(icell))) <= (dx./2) & abs(yp(ip)-(Y(icell))) <= (dy./2))';
            end
            count = count+length(pfound);
            nbp = length(pfound); %number of particle in the sampled cell
            agesp(count-length(pfound)+1:count) = Ages_particles(pfound); %Store particles age found in the sampling site
        end
        agesp(count+1:end) = [];

        %----- compute Detrital SPDFs -----%
        Detrital_SPDFs = get_SPDF(agesp);
        
       if length(fnr_vector) > 1 %In case of model considering pulse of particles
            SPDFs_for_transient(k,:) = mean(Detrital_SPDFs); %Store the Mean detrital SPDF
       end
    end
    
 
end

%--------------------------- Plot results ---------------------------------
%-------------------- Results from Local Sampling -------------------------
if Sampling_site ==2 
    %Plot SPDFs
    figure
    hold on, box on, grid on;
    Bedrock_SPDF = mean(Bedrock_SPDFs)./sum(mean(Bedrock_SPDFs));
    plot(Age_range,Bedrock_SPDF, 'k','Linewidth',2);
    for i=1:Ssize(1)
        Detrital_SPDFs = Detrital_SPDFs_local(i,:);
        Detrital_SPDF = Detrital_SPDFs./sum(Detrital_SPDFs);
        plot(Age_range,Detrital_SPDF,'Linewidth',2);
    end
    hold off
    xlabel('AHe Ages (Ma)'); ylabel('Probability');
    set(gca,'FontSize',8,'FontName','Arial');
    ylim([0 y_lim]), xlim([0 x_lim]);
    legend('Bedrock','Region 1', 'Region 2', 'Region 3','Region 4');
    print(gcf,['.\DSPDF_Local',NameExp],'-dsvg','-r300');
    
    %Plot CSPDFs
    figure
    hold on, box on, grid on;
    BCSPDF = cumsum(Bedrock_SPDF);
    plot(Age_range,BCSPDF, 'k','Linewidth',2); %Bedrock CSPDF
    %Set matrix for statistical tests
    kuiper_test = zeros(Ssize(1),1);
    KS_test = zeros(Ssize(1),1);
    for i=1:Ssize(1)
        Detrital_SPDFs = Detrital_SPDFs_local(i,:);
        Detrital_SPDF = Detrital_SPDFs./sum(Detrital_SPDFs);
        DCSPDF = cumsum(Detrital_SPDF);
        plot(Age_range,DCSPDF,'Linewidth',2);
        %Compute statistics
        [~,kuiper_test(i)] = kuipertest(BCSPDF,DCSPDF);
        [~,KS_test(i)] = KStest(BCSPDF,DCSPDF);
    end
    xlswrite(['STATISTICS',NameExp,'.xlsx'],kuiper_test,1); %In xlsx file: A1=Region1, A2=Region2,A3=Region3,A4=Region4
    xlswrite(['STATISTICS',NameExp,'.xlsx'],KS_test,2);
    hold off
    ylim([0 1]);
    xlabel('AHe Ages (Ma)'); ylabel('Probability');
    set(gca,'FontSize',8,'FontName','Arial')
    xlim([0 x_lim]); ylim([0 1]);
    print(gcf,['.\CSPDF_Local',NameExp],'-dsvg','-r300');

%------------- Results from Sampling the entire frontal moraine -----------
else
    %Compute mean Bedrock SPDF
    BSPDF_mean = mean(Bedrock_SPDFs)./sum(mean(Bedrock_SPDFs));
    BCSPDF = cumsum(BSPDF_mean);
    %Compute the mean Detrital SPDF from all SPDFs produced
    DSPDF_mean = mean(Detrital_SPDFs)./sum(mean(Detrital_SPDFs)); %Detrital mean SPDF
    DCSPDF_mean = cumsum(DSPDF_mean);
    sorted_SPDF = sort(Detrital_SPDFs,'descend'); %Sort SPDF to get range of SPDFs
    SPDF_plus = sorted_SPDF(1,:);%Upper limit
    SPDF_minus =  sorted_SPDF(end,:);%Lower limit
    DCSPDF = cumsum(Detrital_SPDFs,2); %Detrital CSPDFs
    CSPDF_plus = max(DCSPDF);  %Upper CSPDF  
    CSPDF_minus = min(DCSPDF); %Lower CSPDF  

    %Figures%
    if length(fnr_vector) == 1

        %Plot SPDFs
        figure
        hold on, box on, grid on;
        Shaded_area = [SPDF_plus,fliplr(SPDF_minus)];
        x2 = [Age_range,fliplr(Age_range)]; %for shaded area
        fill(x2,Shaded_area,[0.8627,0.8626,0.8627],'FaceAlpha',0.5,'EdgeColor','none');
        plot(Age_range,BSPDF_mean, 'k','Linewidth',2);
        plot(Age_range,DSPDF_mean, 'r','Linewidth',2);
        hold off
        ylim([0 y_lim])
        xlabel('AHe Ages (Ma)'); ylabel('Probability');
        set(gca,'FontSize',8,'FontName','Arial')
        print(gcf,['.\SPDF',NameExp],'-dsvg','-r300');

        %Plot CSPDFs
        figure
        hold on, box on, grid on;
        Shaded_area = [CSPDF_plus,fliplr(CSPDF_minus)];
        fill(x2,Shaded_area,[0.8627,0.8626,0.8627],'FaceAlpha',0.5,'EdgeColor','none');
        plot(Age_range,BCSPDF, 'k','Linewidth',2);
        plot(Age_range,DCSPDF_mean, 'r','Linewidth',2);
        hold off
        ylim([0 1]);
        xlabel('AHe Ages (Ma)'); ylabel('Probability');
        set(gca,'FontSize',8,'FontName','Arial')
        print(gcf,['.\CSPDF',NameExp],'-dsvg','-r300');
    else
        %Plot SPDFs
        figure
        hold on, box on, grid on;
        plot(Age_range,BSPDF_mean, 'k','Linewidth',2);
        plot(Age_range,SPDFs_for_transient(1,:), 'b','Linewidth',2);
        plot(Age_range,SPDFs_for_transient(2,:), 'g','Linewidth',2);
        plot(Age_range,SPDFs_for_transient(3,:), 'y','Linewidth',2);
        plot(Age_range,SPDFs_for_transient(4,:), 'r','Linewidth',2);
        hold off
        ylim([0 y_lim]);
        xlabel('AHe Ages (Ma)'); ylabel('Probability');
        set(gca,'FontSize',8,'FontName','Arial')
        legend('bedrock','t=500','t=1000','t=2000','t=8500')
        print(gcf,['.\TransientSPDFs_',NameExp],'-dsvg','-r300');
    end
end

%Plot spatial distribution of particles
if show_particles==1
    figure
    load('cmap_jet.mat')
    zdata = bed;
    caxis([0 5]);
    [cdata_M,mintopo,maxtopo] = get_color(bed,colormap(cmap_jet),[0,5],1,1,bed,ice);

    hold on;
    hp = surf(Xc./1000,Yc./1000,(bed)./1000,'Cdata',cdata_M); shading interp;
    cb = colorbar('position',[0.85,0.1,0.02,0.4]);
    vt = [0,0.25,0.5,0.75,1.0];
    set(cb,'ylim',[0,1],'ytick',vt,'yticklabel',mintopo+vt*(maxtopo-mintopo));
    set(get(cb,'ylabel'),'string',['elevation (m)']);
    cdata_N = get_color(Ages_particles,colormap(cmap_jet),[0,5],0,0,bed,0);
    p3=scatter3(xp./1000, yp./1000, (zpr+100)./1000,0.5,cdata_N,'o');
    xlabel('Distance (km)'), ylabel('Distance (km)'); c=colorbar;
    c.Label.String = 'Age (Ma)';
    set(c,'ylim',[4,5],'ytick',vt+4,'yticklabel',3+vt*(14-3));
    set(hp,'facelighting','gouraud','edgelighting','gouraud');
    set(gca,'ambientlightcolor',[.9,.8,.9],'Box','off','FontSize',8,'FontName','Arial');
    material([.4,.4,.4,2,0.1]);
    set(gca,'dataaspectratio',[1,1,1/1],'Visible','off');
    set(c,'position',[0.85,0.55,0.02,0.4]);
    light('position',[100,0,500]*1e3);
    set(gcf,'Units','centimeters','Position',[0,0,10,10],'Color','white')
    view(90,90)
    hold off;
end
F = findall(0,'type','figure','tag','TMWWaitbar');
delete(F)
