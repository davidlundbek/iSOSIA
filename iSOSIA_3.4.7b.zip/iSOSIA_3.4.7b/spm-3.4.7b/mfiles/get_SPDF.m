function [SPDFs] = get_SPDF(agesp)

% This function compute the probability age distributions.

% Read file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('Temporary.mat');
 
%-------------------- Compute SPDFs ---------------------------------------
%Compute age distribution in the cell%
SPDFs = zeros(ntry, length(Age_range));              %Initiate matrix to store SPDFs

f = waitbar(0,'1)','Name','Computing SPDFs...',...
    'CreateCancelBtn','setappdata(gcbf,''canceling'',1)');
setappdata(f,'canceling',0);
% Look for number of try %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k=1:ntry
    
    if getappdata(f,'canceling')
        break
    end
    waitbar(k/ntry,f,sprintf('%d/%d',k,ntry))
    
    if ntry==1
        indx_temp=1:length(agesp);
    else %Considering several sampling process of particles
        if length(agesp) > nb_grains 
            indx_temp = randperm(length(agesp),nb_grains); %Randomly sample nb_grains from the sampling site
            agespart = agesp(indx_temp);                   %Keep ages       
        else
            %If number of particle in the sample site is lower than expected
            if length(agesp) < nb_grains
                disp(['Particle number less than 105 = ',num2str(length(agesp))])
                agespart = agesp;
            end
        end
    end

    if Age_Elevation == 1 %If AFT ages
        [Ages_particles,std,~] = Get_noisy_AFT(agespart.*1e6,ntry); %Get noisy AFT age
        agespart = Ages_particles.*1e-6; %Get ages in million years
        stdp = agespart .* std; %Assign >30% relative uncertainty 
        
    else %if AHe Ages
        stdp = agespart .* std_gauss; %Assign 10% uncertainty
    end
  
    %%%%% Compute detrital SPDFs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [Sages,iSages] = sort(agespart); %Ages sorted
    std_age = stdp(iSages);

    SPDF_matrix_temp = zeros(size(Age_range)); %Initiate vector for detrital SPDF
    for t_index=1:length(Age_range)
        t = Age_range(t_index);
        tc = Sages;
        PDF_grains = exp(-0.5 .* ((t - tc)./(alpha_pdf.*std_age)).^2) ./ (alpha_pdf.*std_age .* sqrt(2*pi)) .* dt_age; %Brandon (1996); Rhul and Hodges (2005)  
        SPDF_matrix_temp(t_index) = sum(PDF_grains(:))'; 
    end
    SPDF= SPDF_matrix_temp/length(Sages); %Normalize by the number of particles
    

    % Store SPDFs %
    SPDFs(k,:) = SPDF;
end 
delete(f)
end
