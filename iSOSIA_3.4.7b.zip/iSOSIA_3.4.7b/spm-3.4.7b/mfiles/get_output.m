
SPM=SPMload;
nx = SPM.mesh.nx;
ny = SPM.mesh.ny;

loaddata;

