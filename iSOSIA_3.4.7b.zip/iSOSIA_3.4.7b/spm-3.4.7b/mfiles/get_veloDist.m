%get ice and hillslope velocity distributions
close all; clear all;

SPM=SPMload;
dx = SPM.mesh.dx;
dy = SPM.mesh.dy;
L = 29.5e+3 ; H = 14.1e+3;
nx = SPM.mesh.nx; ny = SPM.mesh.ny;
[Xc, Yc] = meshgrid([1:nx]*dx-dx/2,[1:ny]*dy-dy/2);
fnr=30;
loaddata;
Ks = SPM.hprop.Ks; sc = SPM.hprop.sc;
load('include.mat')

%For ice
velocity = sliding + deformation;
velo_vector = velocity(ice >0 & polyg_Tied==1);
edgevelo = 0:5:120;
countvelo = histcounts(velo_vector,edgevelo,'Normalization','pdf');
figure
plot(edgevelo, [countvelo,0], 'k')
xlabel('Mean ice velocity (m yr^-^1)'); ylabel('Probability');
set(gca,'FontSize',8,'FontName','Arial')
set(gcf,'Units','centimeters','Position',[0,0,10,5]);
xlim([0 125]); ylim([0 0.15]);
print(gcf,'IceVeloDist.svg','-dsvg');

%For hillslope
bslope_vector = bslope(ice>5 & polyg_Tied==1 & Xc<22150);
fac = 1 - (bslope_vector./sc).^2;
Kdiff = Ks./fac;
hillslope_velocity = Kdiff.*bslope_vector;
edgeveloHill = 0:20;
[countveloHill, edgeveloHill] = histcounts(hillslope_velocity,'Normalization','probability');
figure
plot(edgeveloHill, [countveloHill,0], 'k')
xlabel('Hillslope velocity (m yr^-^1)'); ylabel('Probability');
set(gca,'FontSize',8,'FontName','Arial')
set(gcf,'Units','centimeters','Position',[0,0,10,5]);
xlim([0 20]); ylim([0 0.15]);
print(gcf,'HillVeloDist.svg','-dsvg');

