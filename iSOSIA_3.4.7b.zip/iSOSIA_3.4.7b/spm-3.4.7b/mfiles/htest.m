function htest()

close all;

s0 = 0.3;
ds = 0.25;
h0 = 0.1;
L = 4;

for i=1:10,
    k0 = (L*s0-h0)/exp(s0/ds)
    ds = k0/L*exp(s0/ds)
end


s = linspace(-1,1,100);
hs = L*s;
I = find(s < s0);
hs(I) = k0*exp(s(I)/ds)+h0;

hold on; box on; grid on;
line(s,L*s,'color','b','linestyle','--');
line(s,hs,'color','r');
axis([-1 1 0 2]);