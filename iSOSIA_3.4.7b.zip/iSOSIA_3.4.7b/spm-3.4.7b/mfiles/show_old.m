function show_old()

close all;

%grid data
nx = 100;
ny = 100;
dx = 0.001;
dy = 0.001;

%make mesh
[Xc,Yc] = meshgrid([0:(nx-1)]*dx+dx/2,[0:(ny-1)]*dy-dy/2);
[Xhp,Yhp] = meshgrid([1:nx]*dx,[0:(ny-1)]*dy+dy/2);
[Xvp,Yvp] = meshgrid([0:(nx-1)]*dx+dx/2,[1:ny]*dy);

%load data
fid = fopen(['../output/bed.dat']);
xc = fread(fid,[ny,nx],'double');
yc = fread(fid,[ny,nx],'double');
bed = fread(fid,[ny,nx],'double');
ice = fread(fid,[ny,nx],'double');
dbdx = fread(fid,[ny,nx],'double');
dbdy = fread(fid,[ny,nx],'double');
vx = fread(fid,[ny,nx-1],'double');
exx = fread(fid,[ny,nx],'double');
sxx = fread(fid,[ny,nx],'double');
dsxxdx = fread(fid,[ny,nx-1],'double');
te2 = fread(fid,[ny,nx],'double');
fclose(fid);

subplot(2,2,1);
hold on; grid on; box on;
imagesc(vx);
colorbar

subplot(2,2,2);
hold on; grid on; box on;
imagesc(sxx); set(gca,'fontsize',12); 
cb = colorbar; set(cb,'fontsize',12);

subplot(2,2,3);
hold on; grid on; box on;
imagesc(dsxxdx); 
colorbar

subplot(2,2,4);
hold on; grid on; box on;
imagesc(te2); 
colorbar

L = 20e3;


figure(2)
set(gcf,'units','centimeters','paperunits','centimeters');
set(gcf,'position',[10,10,18,25,],'paperposition',[10,10,18,25]);

subplot(3,2,1); set(gca,'xlim',[0,L]);
hold on; box on; grid on;
line(xc(50,:),te2(50,:),'color','k');
xlabel('Distance'); ylabel('tau_e^2');

subplot(3,2,2); set(gca,'xlim',[0,L]);
hold on; box on; grid on;
line(xc(50,:),sxx(50,:),'color','k');
xlabel('Distance'); ylabel('s_{xx}');

subplot(3,2,3); set(gca,'xlim',[0,L]);
hold on; box on; grid on;
line(xc(50,:),exx(50,:),'color','k');
xlabel('Distance'); ylabel('e_{xx}');

subplot(3,2,4); set(gca,'xlim',[0,L]);
hold on; box on; grid on;
line(xc(50,2:end),vx(50,:),'color','k');
xlabel('Distance'); ylabel('v_{x}');

subplot(3,2,5); set(gca,'xlim',[0,L]);
hold on; box on; grid on;
line(xc(50,2:end),dsxxdx(50,:),'color','k');
xlabel('Distance'); ylabel('dsxx/dx');

subplot(3,2,6); set(gca,'xlim',[0,L]);
hold on; box on; grid on;
line(xc(50,:),ice(50,:),'color','k');
xlabel('Distance'); ylabel('H');

print -depsc profiles_20_usg.eps

%res=load('../source/res.dat');
%figure
%plot(res,'.k');
%set(gca,'yscale','log');
%print -deps res.eps