function [AFT,std,Ns] = Get_noisy_AFT(age,ntry)

% This function resample AFT ages according to the variable uncertainty
% shown in the data presented in Enkelmann and Ehlers (2015).

%set parameters
lambda = 1.55125e-10; %alpha radioactive decay for 238U (Jaffey et al., 1971)
zeta = 245.00;        %Zeta value used in Enkelmann and Ehlers (2015)
rho_d = 1e6;          %track density over U-glass IRMM540R (Enkelmann and Ehlers, 2015) 
NsNi_vector =2:210;   %NsNi range from Enkelmann and Ehlers (2015)

%Apply transformation
r1 = 1; r2 = length(NsNi_vector);
indx_temp = round(r1 + (r2-r1) .* rand(length(age),1)); %randomly sample
NsNi = NsNi_vector(indx_temp);                          %Pick a random value of Ns+Ni in that range

%Compute track density ratio from the noise-free bedrock age
density_ratio = (exp(age.*lambda) - 1) ./ (lambda.*zeta.*0.5.*rho_d); %rhos/rhoi (Brandon (1996), eq. 22)

%Use a binomial distribution to sample a new Ns/Ni value
theta = density_ratio ./ (1+density_ratio); %binomial distribution parameter
Ns = binornd(NsNi, theta);                  %randomly sample Ns value
Ni = NsNi - Ns;                             %deduce Ni

%Compute noisy age 
AFT = 1./lambda .* log(1+ exp(log(lambda*zeta*0.5*rho_d) + log((Ns+0.5)./(Ni+0.5)))); %Brandon (1996), eq. 25
std = sqrt((1./(Ns+0.5)) + (1./(Ni+0.5))); %standard error for the noisy age (Brandon, 1996; eq. 26)

AFT(isinf(AFT)) = age(isinf(AFT)); %handle inf. value by giving the noise-free bedrock ages
    
    
end