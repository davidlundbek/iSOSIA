function [H, pValue] = KStest(x1, x2)

delta = abs(x1'-x2');
KSstatistic   =  max(delta);

% Compute the P-value 

n1     =  length(x1);
n2     =  length(x2);
n      =  n1 * n2 /(n1 + n2);
lambda =  max((sqrt(n) + 0.12 + 0.11/sqrt(n)) * KSstatistic , 0);
j       =  (1:101)';
pValue  =  2 * sum((-1).^(j-1).*exp(-2*lambda.^2*j.^2));
% pValue  =  min(max(pValue, 0), 1)
alpha = 0.05;
H  =  (alpha >= pValue);
end