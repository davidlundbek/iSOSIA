function speedup()

close all;
set(gcf,'units','centimeters','position',[15,5,40,30]);

%first test - no function
n = [1,4,8,12,16,20,24,36,48];
t1 = [23.67,6.08,3.06,5.37,2.15,3.30,1.91,2.28,1.89];
speedup1 = t1(1)./t1;

n = [1,4,8,12,16,20,24,36,48];
t2 = [11.9,3.15,0.99,1.92,0.56,0.65,0.38,0.35,0.31];
speedup2 = t2(1)./t2;

n3 = [1,4,8,12,24,36,48];
t3 = [31.9,8.4,4.3,6.4,3.2,4.0,3.2];
speedup3 = t3(1)./t3;

hold on; grid on; box on;
line([0,48],[0,48],'linewidth',1.5,'color','k','linestyle','--');
plot(n,speedup1,'-ok');
plot(n,speedup2,'-or');
plot(n3,speedup3,'-ob');
xlabel('# treads'); ylabel('Speedup');


