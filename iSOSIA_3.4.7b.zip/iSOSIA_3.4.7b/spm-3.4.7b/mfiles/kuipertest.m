function [Hkp,Qkp]= kuipertest(F1,F2)
[M1, iM1] = max(F1 - F2); [M2, iM2] = max(F2 - F1);
V = M1 + M2;
j = 1:100; Ne = length(F1)*length(F2)/(length(F1)+length(F2));
Qkp = 2.*sum((4.*j.^2.*V.^2.*Ne - 1).*exp(-2.*j.^2.*V.^2.*Ne));
if Qkp > 0.05
    Hkp = 0; %The distributions are the same
else
    Hkp = 1; %The distributions are different
end
end