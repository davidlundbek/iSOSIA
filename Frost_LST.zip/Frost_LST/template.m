function template()

close all;

%mesh dimensions
L = 8e3; H = 11.75e3;
nx = 2*160; ny = 2*235; 

%load default SPM structure
SPM = setup(L,H,nx,ny);
dx = SPM.mesh.dx
dy = SPM.mesh.dy


SPM.mesh.doice = 1; 
SPM.mesh.gmode = 1; %0: SIA, 1:iSOSIA
SPM.mesh.dosliding = 1;  %sliding flag
SPM.mesh.doglacialhydrology = 0;
SPM.mesh.doavalance = 1; 

SPM.mesh.hydromode = 2;  %1:steady state, 2: transient
SPM.mesh.nmoni = 10;
SPM.mesh.doisostasy = 0; %isostasy flag
SPM.mesh.maxtime = 4e3;  %length of simulation
SPM.mesh.filetime = 1e1;  %time between outputs
SPM.mesh.maxdt = 1.0;    %maximum time step
SPM.mesh.ct = 0.5;       %time step scaling factor
SPM.mesh.slidingmode = 1; %0:wertman, 1: budd , 2:Schoof
SPM.mesh.coldbased = 0;
SPM.mesh.dosediment = 1;
SPM.mesh.doglacialsedi = 0; %advect sediment volumes in glaciers
SPM.mesh.maxb = 0.7;     %maximum bed gradient
SPM.mesh.maxs = 0.7;     %maximum ice surface gradient
SPM.mesh.doperiglacial = 1; %periglacial flag
SPM.mesh.dohillslope = 0; %hillslope processes
SPM.mesh.dohillslopeerosion = 0; %sediment production on hillslopes
SPM.mesh.doweathering = 0; %hillslope weathering
SPM.mesh.dodebrisablation = 1; %reduce surface ablation rates due
                               %to debris cover
SPM.mesh.doparticles = 1; 

SPM.parprop.npmax = 2e6; %max number of particles
SPM.parprop.minice = 10.0; %minimum ice thickness for particle formation
SPM.parprop.minsedi = 0.0025; %minimum sediment thickness for particle formation
SPM.parprop.maxsedi = 0.5; %max sediment per particle
SPM.parprop.maxpm = 100; %max particle number in margin cell
SPM.parprop.maxp = 200; %max particle number in ordinary cell
SPM.parprop.minpm = 10; %minimum particle number at margin 
SPM.parprop.minsedim = 0.1; %mimum sediment pickup at margin
                          %The two latter parameters are used to
                          %form sediment along margins without
                          %production of sediment in the landscape


SPM.iprop.gamma = 1.0e-17*(910.0*9.81)^3.0; %Flow constant
SPM.iprop.ifac = 0.0005;       %Relaxation constant (velocity)
SPM.iprop.sfac = 0.025;       %Relaxation constant (stress)
SPM.iprop.vbfac = 0.001;      %Relaxation constant (sliding)
SPM.iprop.maxitt_v = 400;    %Max iteration (velocity)
SPM.iprop.maxitt_s = 400;    %Max iteration (stress)
SPM.iprop.Cs = 0.1;          %Scales sliding velocities
SPM.iprop.gamma = 1.0e-16*(910.0*9.81)^3.0; %Flow constant - scales velocity
SPM.iprop.maxsliding = 1e3;  %Schoof sliding parameter
SPM.iprop.maxdeformation = 1e3; %max def. velocity
SPM.iprop.gamma0 = 0.01;  %Viscosity regelation

%**** hillslope properties **
SPM.hprop.Ks = 0.5;       %hillslope diffusivity
SPM.hprop.sc = 0.4;        %critical slope
SPM.hprop.Ke = 0.01;       %Hillslope erosion coefficient
SPM.hprop.Kw = 5.0e-4;     %Hillslope weathering w = Kw*exp(-Hs/Ls)
SPM.hprop.Ls = 1.0;        %sediment thickness cover factor
SPM.hprop.gamma = 1;       %hillslope landslide strength
SPM.hprop.Nc = 20;         %number of random landslide cells
SPM.hprop.maxsedi = 30;    %max sediment thickness on hillslopes
 
%periglacial prop
SPM.pgprop.Ke = 4.5e-3; %3e-3
SPM.pgprop.Kt = 1.0;         %Transport scaling
SPM.pgprop.maxsedi = 10.0;   %Max sediment for periglacial erosion
SPM.pgprop.maxice = 10.0;    %Max ice for periglacial erosion
SPM.pgprop.minslope = 0.01;   %minimum slope for sediment free cells
SPM.pgprop.minsedi = 1.0;    %expected minimum sediment cover on
                               %slopes smaller than minslope
  
%****** hwprop data ******
SPM.hwprop.Kgw = 1.0e5;    %water conductivity
SPM.hwprop.a2w = 0.01;     %fraction of ablation to glacial water 
SPM.hwprop.hc = 0.01;      %ice porosity
SPM.hwprop.tscale = 0.01;   %time scaling < 1 slows system and
                           %increase timesteps
SPM.mprop.mtype = 2;
SPM.mprop.avaslope = 0.7; %max stable slope for avalances
SPM.mprop.avacurv = -0.05;  %min stable curvature for avalances (wind)
SPM.mprop.lrate = 0.006;   %lapse rate
SPM.mprop.mPDD = 1.5e-3; %2.0
SPM.mprop.dTa = 10;
SPM.mprop.Ldebris = 0.1;  %ablation reduction beneath debris cover
                           %factor = exp(-S/Ldebris)

%***** Flexural isostasy ********
SPM.flexprop.Te = 10.0e3;  %Elastic thickness
SPM.flexprop.rho_r = 2800; %Density of eroded bedrock
SPM.flexprop.rho_s = 2400; %Density of sediment
SPM.flexprop.rho_a = 3250; %Density of asthenosphere
SPM.flexprop.ncall = 10;   %Call isostasy every ncall timestep

%SPM.mprop.Temp = [0,2e3,10e3,12e3,20e3,22e3,30e3;8,0,8,0,8,0,8];   %t;T data

t1 = 2000; T1 = 27.05;
t2 = 2100; T2 = 26.45;
t3 = 2500; T3 = 26.45;
t4 = 2600; T4 = 27.05;
t5 = 3000; T5 = 27.05;
t6 = 3100; T6 = 27.75;
t7 = 4000; T7 = 27.75;

SPM.mprop.Temp = [0,t1,t2,t3,t4,t5,t6,t7;T1,T1,T2,T3,T4,T5,T6,T7]; ...
%t;T data 26.75

%plot(SPM.mprop.Temp(1,:),SPM.mprop.Temp(2,:),'-ok');
%return


%****** bed topography and mass balance
path(path,'./topotoolbox'); 
DEM = GRIDobj('./chhota_shigri_max_rgi32rgi50_srtm30m_utm43n_bed.tif'); 
ICE = GRIDobj('./chhota_shigri_max_rgi32rgi50_srtm30m_utm43n_ice.tif'); 
PRATE = GRIDobj('./chhota_shigri_srtm30m_utm43n_bed_10Be_prod_rates.tif'); 
ATT = GRIDobj('./chhota_shigri_srtm30m_utm43n_bed_10Be_atten_lengths.tif'); 
LST = GRIDobj('./chhota_shigri_srtm30m_utm43_AG100_LST.tif'); 
res = DEM.cellsize;

%grid cell coordinates
x = linspace(0,SPM.mesh.L-dx,SPM.mesh.nx);
y = linspace(0,SPM.mesh.H-dy,SPM.mesh.ny);
[X,Y] = meshgrid(x,y);
 
Zd = flipud(double(DEM.Z)); %bed topography
[nyd,nxd] = size(Zd);
[Xd,Yd] = meshgrid(res*[0:nxd-1],res*[0:nyd-1]);
bed = interp2(Xd-1e3,Yd-2e3,Zd,X,Y,'linear',0);
ice = interp2(Xd-1e3,Yd-2e3,flipud(double(ICE.Z)),X,Y,'linear',0);
Prate = interp2(Xd-1e3,Yd-2e3,flipud(double(PRATE.Z)),X,Y,'linear',0);
atten = interp2(Xd-1e3,Yd-2e3,flipud(double(ATT.Z)),X,Y,'linear',0);


landtemp = interp2(Xd-1e3,Yd-2e3,flipud(double(LST.Z)),X,Y,'linear',0);

load ppoly.mat;
include_i = zeros(size(bed));
I = find(inpolygon(X(:),Y(:),ppx,ppy));
include_i(I) = 1;

%load ppoly2.mat;
include_s = zeros(size(bed));
I = find(inpolygon(X(:),Y(:),ppx,ppy));
include_s(I) = 1;

P = 2.5*(2.4 - 2.0*(Y/H).^(0.5) - 1.0*(X/L).^(0.5)); 
I = find(P < 0); P(I) = 0;
I = find(include_i == 0); P(I) = 0;

%comput aspect
%dzdx = zeros(size(bed));
%dzdy = zeros(size(bed));
%dzdx(:,2:end) = diff(bed,1,2)/SPM.mesh.dx;
%dzdy(2:end,:) = diff(bed,1,1)/SPM.mesh.dy;

%aspect = pi-atan2(dzdx,dzdy);
%fa = cos(aspect+0.3)+1; 
%P = P.*fa;

SPM.data.precip = P;
load ini2.mat;

SPM.data.bed = bed;
SPM.data.ice = ice;
%SPM.data.shielding = shielding;
SPM.data.atten = atten;
SPM.data.CNprod = Prate;
SPM.data.include = uint8(include_i); 
SPM.data.include_s = uint8(include_s); 
SPM.data.phi = landtemp; %use placeholder phi to store land surface temp
 
SPM.data.fixflag(:,1) = 1;
%SPM.data.fixflag(:,end) = 1;
%SPM.data.fixflag(1,:) = 1;
%SPM.data.fixflag(end,:) = 1;


figure
set(gcf,'units','normalized');
set(gcf,'position',[.1,.1,.7,.7]);

subplot(2,3,1);
hold on; box on;
surf(X,Y,bed,bed); colorbar; 
axis equal;
shading interp;
title('Elevation');

subplot(2,3,2);
hold on; box on;
surf(X,Y,bed,P); colorbar; 
axis equal;
shading interp;
title('Precipitation');

subplot(2,3,3);
hold on; box on;
surf(X,Y,bed,SPM.data.CNprod); colorbar; 
axis equal;
shading interp;
title('Production rate');

subplot(2,3,4);
hold on; box on;
surf(X,Y,bed,SPM.data.atten); colorbar; 
axis equal;
shading interp;
title('Attenuation');

subplot(2,3,5);
hold on; box on;
surf(X,Y,bed,SPM.data.include_s); colorbar; 
axis equal;
shading interp;
title('Production rate sediment');

subplot(2,3,6);
hold on; box on;
surf(X,Y,bed,SPM.data.phi); colorbar; 
axis equal;
shading interp;
title('Attenuation sediment');



%LAT = [32.2285,	32.2325, 32.2366, 32.2409, 32.2449];
%LON = [77.5113, 77.5123, 77.5142, 77.5158, 77.5182];
%[xs,ys] = mfwdtran(DEM.georef.mstruct,LAT,LON);
%xs = xs - DEM.georef.SpatialRef.XWorldLimits(1)-1e3;
%ys = ys - DEM.georef.SpatialRef.YWorldLimits(1)-2e3;
%N10s = [27093, 37910, 53607, 61631, 36368];
%dN10s = [1664, 2058, 2488, 2649, 2022];

%zs = interp2(X,Y,bed,xs,ys);
%hold on;
%for i=1:length(xs),
%    plot3(xs,ys,zs+100,'or','markersize',20);
%end;


%mass balance function (positive degree day)
SPM = massbalance(SPM,1);

%write input
write(SPM);

%save CNpoints.mat xs ys N10s dN10s;