function SPM = SPMload()

%  SPM = SPMload() reads and returns SPM structure from current
%  configuration
%
%    DLH - 04.05.05
%

load('./input/SPM.mat');
