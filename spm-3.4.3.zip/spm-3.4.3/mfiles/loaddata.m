

    %load data
    fid = fopen(['./output/output',num2str(fnr),'.dat']);
    xc = fread(fid,[ny,nx],'double');
    yc = fread(fid,[ny,nx],'double');
    bed = fread(fid,[ny,nx],'double');
    ice = fread(fid,[ny,nx],'double');
    bslope = fread(fid,[ny,nx],'double');
    hydro = fread(fid,[ny,nx],'int');
    slidingslope = fread(fid,[ny,nx],'double');
    ssedi = fread(fid,[ny,nx],'double'); 
    bsedi = fread(fid,[ny,nx],'double');
    msedi = fread(fid,[ny,nx],'double');
    sN10 = fread(fid,[ny,nx],'double'); 
    particles = fread(fid,[ny,nx],'int');
    sediment = fread(fid,[ny,nx],'double');
    tn = fread(fid,[ny,nx],'double');
    te = fread(fid,[ny,nx],'double');
    ts = fread(fid,[ny,nx],'double');
    sliding = fread(fid,[ny,nx],'double');
    deformation = fread(fid,[ny,nx],'double');
    td2 = fread(fid,[ny,nx],'double');
    bmelt = fread(fid,[ny,nx],'double');
    quarrying = fread(fid,[ny,nx],'double');
    accrate = fread(fid,[ny,nx],'double');
    massb = fread(fid,[ny,nx],'double');
    cbs = fread(fid,[ny,nx],'double');
    te2 = fread(fid,[ny,nx],'double');
    weathering = fread(fid,[ny,nx],'double');
    abrasion = fread(fid,[ny,nx],'double');
    isostasy = fread(fid,[ny,nx],'double');
    periglacial = fread(fid,[ny,nx],'double');
    Ts = fread(fid,[ny,nx],'double');
    hillslope = fread(fid,[ny,nx],'double');
    Ta = fread(fid,[ny,nx],'double');
    Tb = fread(fid,[ny,nx],'double');
    sfac = fread(fid,[ny,nx],'double');
    icemargin = fread(fid,[ny,nx],'int');
    Ac = fread(fid,[ny,nx],'double');
    hw = fread(fid,[ny,nx],'double');
    qw = fread(fid,[ny,nx],'double');
    sxx = fread(fid,[ny,nx],'double');
    water = fread(fid,[ny,nx],'double');
    Pw = fread(fid,[ny,nx],'double');
    SLf = fread(fid,[ny,nx],'double');
    mw = fread(fid,[ny,nx],'double');
    vx = fread(fid,[ny,nx+1],'double');
    vy = fread(fid,[ny+1,nx],'double');
    vxres = fread(fid,[ny,nx+1],'double');
    vyres = fread(fid,[ny+1,nx],'double');
    %for i=1:20,
    %    Vs{i} = fread(fid,[ny,nx],'double');
    %end
    fclose(fid);
 
    sN10 = sN10./(ssedi + 1e-3);