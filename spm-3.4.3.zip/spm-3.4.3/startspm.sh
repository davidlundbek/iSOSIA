#!/bin/bash 

if [ $# -eq 0 ]; then
	echo "usage: $0 <SPMFOLDER> <MODELFOLDER> <QUEUE>"
	echo "No arguments supplied. Example:"
	echo "  $0 ~/spm-3.1.3 ~/a1 q4"
else

EMAIL=david@geo.au.dk

MODELFOLDER=$2

#QUEUE=q4
QUEUE=$3
CORES=12

HOURS=48

#SPMFOLDER=~/spm-3.1.3
SPMFOLDER=$1
BIN=spm

echo "Removing old files from the model output directory"
rm -rf $MODELFOLDER/output/*

echo "#!/bin/bash
# These commands set up the Grid Environment for your job:

# Job name and folder. Edit both this entry and MODELFOLDER!!
#PBS -N `basename $MODELFOLDER`

# Specify job requirements.
#  How many nodes (nodes) to use, no. of cores (ppn)?
#  The process walltime (hh:mm:ss)?
#PBS -l nodes=1:ppn=$CORES,walltime=$HOURS:00:00

# Specify queue
# q4, q8, qfat, q12, q12fat
#PBS -q $QUEUE

# Your e-mail address
#PBS -M $EMAIL

# Mail options:
#  a: Mail is sent when the job is aborted by the batch system
#  b: Mail is sent when the job begins execution
#  e: Mail is sent when the job terminates
#PBS -m abe

MODELFOLDER=$MODELFOLDER

# Print the user@hostname, the time and the date
echo '\`whoami\`@\`hostname\`' 
echo 'Start at \`date\`'

# Compile the program
cd $SPMFOLDER/source && make

# Run the model
$SPMFOLDER/$BIN $MODELFOLDER

# Print the time and date again
echo 'End at \`date\`'
" > $MODELFOLDER/job-script.sh

echo "Job script written as $MODELFOLDER/job-script.sh"
echo "cd $MODELFOLDER && qsub job-script.sh"
cd $MODELFOLDER && qsub job-script.sh
echo "Submitted with Torque. See status of your jobs with 'mj'"

fi
