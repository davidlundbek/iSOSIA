function DEMs=makeDEMs(Z,res,levels)

%size of Z matrix
[ny,nx] = size(Z);

%generate X matrix
X = ones(ny,1)*[0:nx-1]*res;

%generate Y matrix
Y = [0:ny-1]'*ones(1,nx)*res;

DEMs{1}.X = X;
DEMs{1}.Y = Y;
DEMs{1}.Z = Z;
DEMs{1}.res = res;

for i=1:levels,
  
  eval(['DEMs{',num2str(i+1),'}=thinDEM(DEMs{',num2str(i),'});']);
  eval(['DEMs{',num2str(i+1),'}.res=2*DEMs{',num2str(i),'}.res;']);
end;
